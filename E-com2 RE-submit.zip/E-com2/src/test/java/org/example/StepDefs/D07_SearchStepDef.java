package org.example.StepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_HomePage;
import org.testng.asserts.SoftAssert;

public class D07_SearchStepDef {
    P03_HomePage homePage = new P03_HomePage();
    @When("user go to search field")
    public void userGoToSearchField(){
        homePage.searchItem.click();
    }
    @And("user enter {string}")
public void userEnter(String arg0){
    homePage.searchItem.sendKeys(arg0);
    homePage.searchButton.click();
}

    @Then("user should find {string} in search result")
    public void userShouldFindInSearchResult(String arg0) {
        SoftAssert softAssert = new SoftAssert();
        String ActualURL="https://demo.nopcommerce.com/search?q=";
        String ExpectedURL= Hooks.driver.getCurrentUrl();
        softAssert.assertTrue(ActualURL.contains(ExpectedURL));
        for (int i =0 ; i<homePage.productItems().size();i++)
        {
            String productItem = homePage.productItems().get(i).getText().toLowerCase();
            softAssert.assertTrue(productItem.contains(arg0));
        }
        softAssert.assertAll();
    }

    @Then("user should find {string} in the search result")
    public void userShouldFindInTheSearchResult(String arg0) {
        SoftAssert softAssert=new SoftAssert();
        homePage.productItem.click();
        String productItem = homePage.sku.getText();
        softAssert.assertTrue(productItem.contains(arg0));
        softAssert.assertAll();
    }

}
