package org.example.StepDefs;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_HomePage;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.Iterator;
import java.util.Set;

public class D06_FollowUsStepDef {
    P03_HomePage homePage = new P03_HomePage();
    @When("user click on facebook link")
    public void userClickOnFacebookLink (){
        homePage.faceBook.click();
    }

    @Then("user navigates to facebook website")
    public void userNavigatesToFacebookWebsite() throws InterruptedException {
        Set<String> windows= Hooks.driver.getWindowHandles();
        Iterator<String> iterator=windows.iterator();
        String tab1= iterator.next();
        String tab2= iterator.next();
        Hooks.driver.switchTo().window(tab2);
        Thread.sleep(1000);
        String ExpectedURL="https://www.facebook.com/nopCommerce";
        String ActualURL=Hooks.driver.getCurrentUrl();
        Assert.assertEquals(ActualURL,ExpectedURL);
    }

@When("user click on Twitter link")
    public void userClickOnTwitterLink (){
        homePage.twitter.click();
}


    @Then("user navigates to twitter website")
    public void userNavigatesToTwitterWebsite() throws InterruptedException {
        Set<String>windows= Hooks.driver.getWindowHandles();
        Iterator<String> iterator=windows.iterator();
        String tab1= iterator.next();
        String tab2= iterator.next();
        Hooks.driver.switchTo().window(tab2);
        Thread.sleep(1000);
        String ExpectedURL="https://twitter.com/nopCommerce";
        String ActualURL=Hooks.driver.getCurrentUrl();
        Assert.assertEquals(ActualURL,ExpectedURL);

    }

    @When("user click on youtube link")
    public void userClickOnYoutubeLink() {
    homePage.youtube.click();
    }

    @Then("user navigates to youtube website")
    public void userNavigatesToYoutubeWebsite() throws InterruptedException {
        Set<String>windows= Hooks.driver.getWindowHandles();
        Iterator<String> iterator=windows.iterator();
        String tab1= iterator.next();
        String tab2= iterator.next();
        Hooks.driver.switchTo().window(tab2);
        Thread.sleep(1000);
        String ExpectedURL="https://www.youtube.com/user/nopCommerce";
        String ActualURL=Hooks.driver.getCurrentUrl();
        Assert.assertEquals(ActualURL,ExpectedURL);
    }

    @When("user click on rss link")
    public void userClickOnRssLink() {
        homePage.rss.click();
    }

    @Then("user navigates to rss website")
    public void userNavigatesToRssWebsite() throws InterruptedException {
        Set<String>windows= Hooks.driver.getWindowHandles();
        Iterator<String> iterator=windows.iterator();
        String tab1= iterator.next();
        String tab2= iterator.next();
        Hooks.driver.switchTo().window(tab2);
        Thread.sleep(1000);
        String ExpectedURL="https://demo.nopcommerce.com/news/rss/1";
        String ActualURL=Hooks.driver.getCurrentUrl();
        Assert.assertEquals(ActualURL,ExpectedURL);
    }
}
