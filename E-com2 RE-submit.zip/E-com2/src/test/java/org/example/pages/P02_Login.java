package org.example.pages;

import org.example.StepDefs.Hooks;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class P02_Login {
    public  P02_Login (){
        PageFactory.initElements(Hooks.driver,this);
    }
    @FindBy (className = "ico-login")
    public WebElement Loginbtn;
    @FindBy (name = "Email")
    public WebElement Email;
    @FindBy (name = "Password")
    public WebElement password;
    @FindBy (xpath = "//*[@class='button-1 login-button']")
    public WebElement loginBtn;
    @FindBy (xpath = "//*[@class='message-error validation-summary-errors']")
    public WebElement ErrorMessage;
}
