package org.example.StepDefs;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_HomePage;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.util.Random;

public class D04_HoverStepDef {
P03_HomePage homePage = new P03_HomePage();
    int randomCategory= new Random().nextInt(3);
    int randomSubCategory= new Random().nextInt(3);
@When("user hover on main category selectsub category appear")
    public void userHoverOnMainCategorySelectsubCategoryAppear (){
    Actions actions =new Actions(Hooks.driver);
    actions.moveToElement(homePage.categories().get(randomCategory)).perform();
    String mainCategory= homePage.categories().get(randomCategory).getText();
    homePage.subCategories(randomCategory).get(randomSubCategory).click();

}

    @Then("user find sub category name in the title")
    public void userFindSubCategoryNameInTheTitle() {
        String subCategory=homePage.subCategories(randomCategory).get(randomSubCategory).getText();
        String pageTitle=homePage.pageTitle.getText();
        Assert.assertTrue( pageTitle.contains(subCategory));

    }
}
