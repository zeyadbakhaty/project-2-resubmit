package org.example.pages;

import org.example.StepDefs.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class P01_Register {
public P01_Register (){
    PageFactory.initElements(Hooks.driver,this);
}
@FindBy(className = "ico-register")
    public WebElement registerLink;

@FindBy (id = "gender-male")
    public WebElement genderMale;

@FindBy (id = "FirstName")
    public WebElement firstName;
@FindBy (id = "LastName")
    public WebElement lastName;
@FindBy (name = "DateOfBirthDay")
    public WebElement DateOfBirthDay;
@FindBy (name = "DateOfBirthMonth")
    public WebElement DateOfBirthMonth;
@FindBy (name = "DateOfBirthYear")
    public WebElement DateOfBirthYear;
@FindBy (id = "Email")
    public WebElement Email;
@FindBy (id = "Password")
    public WebElement password;
@FindBy (id = "ConfirmPassword")
    public WebElement ConfirmPassword;
@FindBy (id = "register-button")
    public WebElement registerBtn;
    @FindBy(className = "result")
    public WebElement successMessage;
@FindBy (className = "result")
    public WebElement successResult;




}
