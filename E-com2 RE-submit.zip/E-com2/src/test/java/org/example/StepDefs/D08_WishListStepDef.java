package org.example.StepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_HomePage;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class D08_WishListStepDef {
    P03_HomePage homePage = new P03_HomePage();
    @When("user click on wishlist BTN of the product")
    public void userClickOnWishlistBTNOfTheProduct() {
        homePage.wishlistButton.click();
    }

    @Then("successful message appear")
    public void successfulMessageAppear() {
        String ExpectedMessage = "The product has been added to your wishlist";
        String ActualMessage = homePage.successMessage.getText();
        SoftAssert softAssert= new SoftAssert();
        softAssert.assertTrue(ActualMessage.contains(ExpectedMessage));
        String ExpectedColor="#4bb07a";
        String ActualColor= Color.fromString(homePage.successMessage.getCssValue("background-color")).asHex();
        softAssert.assertEquals(ActualColor,ExpectedColor);

    }

    @And("user click on wishlist link")
    public void userClickOnWishlistLink() {
        WebDriverWait wait = new WebDriverWait(Hooks.driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.invisibilityOf(homePage.successMessage));
        homePage.wishListLink.click();
        
    }

    @Then("quantity of products displayed will not equal zero")
    public void quantityOfProductsDisplayedWillNotEqualZero() {
        String itemQuantity= homePage.itemQuantity.getAttribute("value");
        Assert.assertNotEquals(itemQuantity ,0);
    }
}
