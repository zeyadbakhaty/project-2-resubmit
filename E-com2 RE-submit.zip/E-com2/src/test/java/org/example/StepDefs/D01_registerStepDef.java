package org.example.StepDefs;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P01_Register;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

public class D01_registerStepDef {
    P01_Register register = new P01_Register();

    @Given("user go to register page")
    public void user_go_to_register_page (){
        WebElement registerLink = register.registerLink;
        registerLink.click();
    }
    @When("user select Gender")
            public void genderMale (){
        register.genderMale.click();
        }

        @And("user enter first Name")
    public void userEnterFirstName (){
        register.firstName.sendKeys("Zeyad");
        }
        @And("user enter last Name")
    public void userEnterlastName(){
        register.lastName.sendKeys("Amr");
        }
        @And("user enter date of birth")
    public void EnterDateOfBirth (){
        Select day = new Select(register.DateOfBirthDay) ;
        day.selectByValue("20");
        Select month = new Select(register.DateOfBirthMonth);
        month.selectByValue("5");
        Select year = new Select(register.DateOfBirthYear);
        year.selectByValue("1996");
        }
        @And("user enter valid email")
    public void fillEmail (){
        register.Email.sendKeys("zeyad.bakhaty@hotmail.com");
        }
        @And("user fills password fields and confirmed password")
    public void fillpassword (){
        register.password.sendKeys("p@ssword");
        register.ConfirmPassword.sendKeys("p@ssword");

    }
    @And("user click on register button")
    public void clickOnRegBtn (){
        register.registerBtn.click();
    }
    @Then("success message displayed")
    public void successMessage (){
        String expectedMessage = "Your registration completed";
        String acutalMessage = register.successResult.getText();
        SoftAssert softAssert = new SoftAssert();
        softAssert.assertEquals(acutalMessage,expectedMessage);
        String expectedColor = "rgba(76, 177, 124, 1)";
        String actualColor = register.successResult.getCssValue("color");
        softAssert.assertEquals(actualColor,expectedColor);
        softAssert.assertAll();


    }



}


