package org.example.StepDefs;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_HomePage;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;


public class D03_CurrencyStepDef {
    P03_HomePage homePage = new P03_HomePage();

    @When("user change currency to Euro")
    public void userChangeCurrencyToEuro() {
        Select select= new Select(homePage.currency) ;
        select.selectByVisibleText("Euro");
    }

    @Then("price of the products will change")
    public void priceOfTheProductsWillChange() {
        for (int i=0;i<homePage.prices().size();i++){
            String ProductPrice = homePage.prices().get(i).getText();
            Assert.assertTrue(ProductPrice.contains("€"));
        }
    }
}
