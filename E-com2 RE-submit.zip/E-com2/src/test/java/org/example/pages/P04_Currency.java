package org.example.pages;

import org.example.StepDefs.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class P04_Currency {
public P04_Currency(){
    PageFactory.initElements(Hooks.driver,this);
}
    @FindBy(id = "customerCurrency")
    public WebElement currency;

    @FindBy( css = "span[class='price actual-price']")
    public  WebElement productsPrice;

    public List<WebElement> prices()
    {

        List<WebElement>prices= Hooks.driver.findElements(By.cssSelector("span[class='price actual-price']"));
        return  prices;
    }
}
